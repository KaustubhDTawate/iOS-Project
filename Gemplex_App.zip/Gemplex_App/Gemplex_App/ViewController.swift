//
//  ViewController.swift
//  Gemplex_App
//
//  Created by Kaustubh Tawate on 05/06/21.
//

import UIKit


class ViewController: UIViewController {
    
    // MARK: - IBOutlets -
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var collectionViewHome: UICollectionView!
    @IBOutlet weak var collectionViewAlbums: UICollectionView!
    @IBOutlet weak var collectionViewSingles: UICollectionView!
    @IBOutlet weak var collectionViewInstrumental: UICollectionView!
    @IBOutlet weak var collectionViewGenres: UICollectionView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var viewPayment: UIView!
    @IBOutlet weak var viewBBPS: UIView!
    @IBOutlet weak var viewLoan: UIView!
    @IBOutlet weak var viewDeposit: UIView!
    @IBOutlet weak var bottomVIew: UIView!
    
    @IBOutlet weak var viewHome: UIView!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var lblHOme: UILabel!
    
    @IBOutlet weak var viewMovies: UIView!
    @IBOutlet weak var btnMovies: UIButton!
    @IBOutlet weak var lblMovies: UILabel!
    
    @IBOutlet weak var viewMusic: UIView!
    @IBOutlet weak var btnMusic: UIButton!
    @IBOutlet weak var lblMusic: UILabel!
    
    @IBOutlet weak var lblAlbum: UILabel!
    @IBOutlet weak var lbInstrumental: UILabel!
    
    
    // MARK:- Variables  -
    
    var dashboardDataImgArray = [UIImage]()
    var dashboardHomeArray = [#imageLiteral(resourceName: "MusicGenres"),#imageLiteral(resourceName: "film-converted"),#imageLiteral(resourceName: "song-converted")]
    let dashboardMusicImgArray = [#imageLiteral(resourceName: "movie-converted"),#imageLiteral(resourceName: "MusicGenres"),#imageLiteral(resourceName: "song-converted")]
    
    var dashboardAlbumArray = [UIImage]()
    var homeDashboardAlbumArray = [#imageLiteral(resourceName: "Series1"),#imageLiteral(resourceName: "Series2"),#imageLiteral(resourceName: "Series3")]
    let musicDashboardAlbumArray = [#imageLiteral(resourceName: "Music1"),#imageLiteral(resourceName: "Music3"),#imageLiteral(resourceName: "Music4"),#imageLiteral(resourceName: "Music2")]
    
    let  musicDataImgArray = [#imageLiteral(resourceName: "MusicGenres"),#imageLiteral(resourceName: "film-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted")]
    let movieImgArray = [#imageLiteral(resourceName: "MusicGenres"),#imageLiteral(resourceName: "film-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted"),#imageLiteral(resourceName: "song-converted")]
    
    // MARK:- VC Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
   }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
   }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    // MARK:- Private Functions -
    
    private func initialSetUp(){
        
        self.transactionSeledction(btnHome: UIColor.getRegistrationSelectedColor() , btnMovies: UIColor.white, btnMusic: UIColor.white, lblHome: UIColor.getRegistrationSelectedColor(), lblMovies: UIColor.white, lblMusic: UIColor.white )
        
        self.lblAlbum.text = "Series"
        self.lbInstrumental.text = "Non Fiction"
        self.dashboardDataImgArray = dashboardHomeArray
        dashboardAlbumArray = homeDashboardAlbumArray
    }
    
    func transactionSeledction(btnHome :UIColor ,btnMovies :UIColor , btnMusic :UIColor ,lblHome :UIColor ,lblMovies :UIColor,lblMusic :UIColor) {
        
        self.btnHome.setTitleColor(btnHome, for: .normal)
        self.btnMovies.setTitleColor(btnMovies, for: .normal)
        self.btnMusic.setTitleColor(btnMusic, for: .normal)
        
        self.lblHOme.backgroundColor = lblHome
        self.lblMovies.backgroundColor = lblMovies
        self.lblMusic.backgroundColor = lblMusic
    }
    
    // MARK:- IB Actions -
    @IBAction func btnTabsClicked(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            self.transactionSeledction(btnHome: UIColor.getRegistrationSelectedColor() , btnMovies: UIColor.white, btnMusic: UIColor.white, lblHome: UIColor.getRegistrationSelectedColor(), lblMovies: UIColor.white, lblMusic: UIColor.white  )
            self.lblAlbum.text = "Series"
            self.lbInstrumental.text = "Non Fiction"
            self.dashboardDataImgArray = dashboardHomeArray
            dashboardAlbumArray = homeDashboardAlbumArray
            collectionViewHome.reloadData()
            collectionViewAlbums.reloadData()
        case 1:
            self.transactionSeledction(btnHome: UIColor.white, btnMovies: UIColor.getRegistrationSelectedColor(), btnMusic: UIColor.white, lblHome: UIColor.white, lblMovies: UIColor.getRegistrationSelectedColor(), lblMusic: UIColor.white )
            self.lblAlbum.text = "Original Web Film"
        case 2:
            self.transactionSeledction(btnHome: UIColor.white, btnMovies: UIColor.white, btnMusic: UIColor.getRegistrationSelectedColor(), lblHome:UIColor.white, lblMovies: UIColor.white, lblMusic:UIColor.getRegistrationSelectedColor())
            self.lblAlbum.text = "Album"
            self.lbInstrumental.text = "Instrumental"
            self.dashboardDataImgArray = self.dashboardMusicImgArray
            dashboardAlbumArray = musicDashboardAlbumArray
            collectionViewHome.reloadData()
            collectionViewAlbums.reloadData()
        default:
            break
        }
        
    }
    
}


// MARK: - UICollectionViewDelegate,UICollectionViewDataSource -

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        switch collectionView.tag {
        case 100:
            return self.dashboardDataImgArray.count
        case 200:
            return  self.dashboardAlbumArray.count
        case 300:
            return  self.dashboardDataImgArray.count
        case 400:
            return  self.dashboardDataImgArray.count
        case 500:
            return  self.dashboardDataImgArray.count
        default:
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch collectionView.tag {
        case 100:
            
            guard let cell : HomeCell = self.collectionViewHome.dequeueReusableCell(withReuseIdentifier: "HomeCell", for: indexPath)as? HomeCell else {
                return UICollectionViewCell()
            }
        
            cell.imgTitle.image = self.dashboardDataImgArray[indexPath.row]
            
            return cell
            
        case 200:
            
            guard let cell : AlbumCell = self.collectionViewAlbums.dequeueReusableCell(withReuseIdentifier: "AlbumCell", for: indexPath)as? AlbumCell else {
                return UICollectionViewCell()
            }
            
            cell.imgTitle.image = self.dashboardAlbumArray[indexPath.row]
            
            return cell
            
        case 300:
            
            guard let cell : SinglesCell = self.collectionViewSingles.dequeueReusableCell(withReuseIdentifier: "SinglesCell", for: indexPath)as? SinglesCell else {
                return UICollectionViewCell()
            }
            
            cell.imgTitle.image = self.dashboardDataImgArray[indexPath.row]
            
            return cell
            
        case 400:
            
            guard let cell : InstrumentalCell = self.collectionViewInstrumental.dequeueReusableCell(withReuseIdentifier: "InstrumentalCell", for: indexPath)as? InstrumentalCell else {
                return UICollectionViewCell()
            }
            
            cell.imgTitle.image = self.dashboardDataImgArray[indexPath.row]
            
            return cell
            
        case 500:
            
            guard let cell : GenresCell = self.collectionViewGenres.dequeueReusableCell(withReuseIdentifier: "GenresCell", for: indexPath)as? GenresCell else {
                return UICollectionViewCell()
            }
            
            cell.imgTitle.image = self.dashboardDataImgArray[indexPath.row]
            
            return cell
            
        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
       
        }
    
    
    // scroll collection view using page control -
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let visibleRect = CGRect(origin: self.collectionViewHome.contentOffset, size: self.collectionViewHome.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        if let visibleIndexPath = self.collectionViewHome.indexPathForItem(at: visiblePoint) {
            self.pageControl.currentPage = visibleIndexPath.row
        }
    }
}


// MARK: - UICollectionViewDelegateFlowLayout -

extension ViewController : UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        switch collectionView.tag {
        case 100:
            return CGSize(width: self.collectionViewHome.frame.width , height: self.collectionViewHome.frame.height)
        case 200:
            return CGSize(width: self.collectionViewAlbums.frame.width / 3 , height: self.collectionViewAlbums.frame.height )
        case 300:
            return CGSize(width: self.collectionViewSingles.frame.width / 3 , height: self.collectionViewSingles.frame.height )
        case 400:
            return CGSize(width: self.collectionViewInstrumental.frame.width / 3 , height: self.collectionViewInstrumental.frame.height )
        case 500:
            return CGSize(width: self.collectionViewGenres.frame.width / 3 , height: self.collectionViewGenres.frame.height  )
        default:
            return CGSize(width: 0, height: 0)
        }
    }
}

// MARK: - UICollectionViewCell -

class HomeCell: UICollectionViewCell {
    
    @IBOutlet weak var imgTitle: UIImageView!
    
}

// MARK: - UICollectionViewCell -

class AlbumCell: UICollectionViewCell {
    
   
    @IBOutlet weak var imgTitle: UIImageView!
    
  
}

// MARK: - UITableViewCell -

class SinglesCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imgTitle: UIImageView!
    
}

// MARK: - UITableViewCell -

class InstrumentalCell: UICollectionViewCell {
    
   
    @IBOutlet weak var imgTitle: UIImageView!
    
 
}

// MARK: - UITableViewCell -

class GenresCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imgTitle: UIImageView!
    
   
}

extension UIColor{
    class func getRegistrationSelectedColor() -> UIColor{
        return #colorLiteral(red: 0.2825444987, green: 0.5400153786, blue: 0.5743992353, alpha: 1)
    }
}

