//
//  AlbumDetailsController.swift
//  Gemplex_App
//
//  Created by Kaustubh Tawate on 10/06/21.
//

import Foundation
import UIKit

class AlbumDetailsController : UIViewController {
    
    @IBOutlet weak var imgSong: UIImageView!
    @IBOutlet weak var lblSOng: UILabel!
    
    var imageSong = UIImage()
    var songName = ""
    
    
    // MARK:- VC Lifecycle -
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
   }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
   }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    func initialSetup(){
        imgSong.image = imageSong
        lblSOng.text = songName
    }
}
